package ems;

public enum DEPARTMENT {
	HR, IT, SALES
}
