package ems;

public enum GENDER {
	MALE, FEMALE, OTHER
}
