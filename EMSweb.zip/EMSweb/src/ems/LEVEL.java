package ems;

public enum LEVEL {
	MANAGER, NONMANAGER
}
