package ems.Servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.SQLIntegrityConstraintViolationException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import ems.DEPARTMENT;
import ems.GENDER;
import ems.LEVEL;
import ems.util.ConnectionManager;
import ems.util.Employee;

/**
 * Servlet implementation class EMServlet
 */
@WebServlet("/EMServlet")
public class EMServlet extends HttpServlet {
	public static Employee employee = new Employee();
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public EMServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.getRequestDispatcher("AddEmployee.jsp").forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		System.out.println(request.getParameter("fullname"));
		String fullName = request.getParameter("fullname");
		String Age = request.getParameter("age");
		String phone = request.getParameter("number");
		String sex = request.getParameter("gender");
		String dep = request.getParameter("department");
		String DateofBirth = request.getParameter("dob");
		//String email = request.getParameter("emailaddress");
		String Salary = request.getParameter("salary");
		String SSN = request.getParameter("ssn");
		String Reportsto = request.getParameter("reportsTo");
		String lvl = request.getParameter("level");
		String Address = request.getParameter("street") + "- " + request.getParameter("city") + "- "
				+ request.getParameter("state") + "- " + request.getParameter("zipcode");
		// request.getParameter("address");
		String title = request.getParameter("jobtitle");
		// String id = "1";

		employee.setName(fullName);
		employee.setAge(Age);
		employee.setContactNumber(phone);
		employee.setAddress(Address);
		// ----------------------------------GENDER
		// ENUM----------------------------------
		if (sex.equalsIgnoreCase("male")) {
			employee.setGender(GENDER.MALE);
		} else if (sex.equalsIgnoreCase("female")) {
			employee.setGender(GENDER.FEMALE);
		} else if (sex.equalsIgnoreCase("other")) {
			employee.setGender(GENDER.OTHER);
		}
		// ----------------------------------DEPARTMENT
		// ENUM----------------------------------
		if (dep.equalsIgnoreCase("hr")) {
			employee.setDepartment(DEPARTMENT.HR);
		} else if (dep.equalsIgnoreCase("it")) {
			employee.setDepartment(DEPARTMENT.IT);
		} else if (dep.equalsIgnoreCase("sales")) {
			employee.setDepartment(DEPARTMENT.SALES);
		}
		employee.setDob(DateofBirth);
		//---------------------------------------EMAIL generator------------------------------------------------------
		String[] splitStr = employee.getName().split("\\s+");		
		
		employee.setEmail(splitStr[0]+ employee.getAge()+"@collabera.com" );
		System.out.println(employee.getEmail());
		employee.setSalary(Salary);
		employee.setSsn(SSN);
		employee.setReportsTo(Reportsto);
		employee.setJobTitle(title);
		// int gen = Integer.valueOf(id) + 1;
		employee.setId(employee.getEmail());
		// ----------------------------------LEVEL
		// ENUM----------------------------------
		if (lvl.equalsIgnoreCase("MANAGER")) {
			employee.setLvl(LEVEL.MANAGER);
		} else if (lvl.equalsIgnoreCase("NONMANAGER")) {
			employee.setLvl(LEVEL.NONMANAGER);
		}

		String sql = "INSERT INTO employee(Emp_Fullname,Emp_Age,Emp_Date_of_birth,Emp_Email,Emp_ReportsTo,"
				+ "Emp_Gender_id,Emp_address_id,Emp_SSN,Emp_Job_Title,Emp_Salary,Emp_ID,Emp_Department_id,Level_id,Emp_Workphone) "
				+ "VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)";

		try {
			PreparedStatement ps = ConnectionManager.getConnection().prepareStatement(sql);

			ps.setString(1, employee.getName().trim());
			ps.setString(2, employee.getAge().trim());
			ps.setString(3, employee.getDob().trim());
			ps.setString(4, employee.getEmail().trim());
			ps.setString(5, employee.getReportsTo().trim());
			ps.setString(6, employee.getGender().toString().trim());
			ps.setString(7, employee.getAddress().toString().trim());
			ps.setString(8, employee.getSsn().trim());
			ps.setString(9, employee.getJobTitle().trim());
			ps.setString(10, employee.getSalary().trim());
			ps.setString(11, employee.getEmail().trim());
			ps.setString(12, employee.getDepartment().toString().trim());
			ps.setString(13, employee.getLvl().toString().trim());
			ps.setString(14, employee.getContactNumber().trim());
			// ps.setString(15, lvl.trim());

			ps.executeUpdate();
			System.out.println("works");
			// rs.next();

			/*
			 * if (rs.rowUpdated()) {
			 * request.getRequestDispatcher("success.html").forward(request, response); }
			 * else { request.getRequestDispatcher("error.html").forward(request, response);
			 * }
			 */
			request.getRequestDispatcher("index.jsp").forward(request, response);
		} catch (SQLException e) {

			PrintWriter out = response.getWriter();
			response.setContentType("text/html");
			out.println("<script type=\"text/javascript\">");
			out.println("alert('Duplicate Input');");
			out.println("</script>");
			request.getRequestDispatcher("index.jsp").forward(request, response);
		}

	}

}
