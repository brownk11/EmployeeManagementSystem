package ems.Servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class IndexServlet
 */
@WebServlet("/IndexServlet")
public class IndexServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public IndexServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		request.getRequestDispatcher("index.html").forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		/*
		 * String add = "Add"; if (request.getParameter("View") == "View") {
		 * 
		 * request.getRequestDispatcher("ViewEmployee.html").forward(request, response);
		 * 
		 * } else if (request.getParameter("Add").equals(add)) {
		 * response.sendRedirect("http://localhost:8080/EMSweb/AddEmployee.html"); //
		 * request.getRequestDispatcher("AddEmployee.html").forward(request, response);
		 * 
		 * } else if (request.getParameter("Update") == "Update") {
		 * 
		 * request.getRequestDispatcher("UpdateEmployee.html").forward(request,
		 * response);
		 * 
		 * } else if (request.getParameter("Delete") == "Delete") {
		 * 
		 * request.getRequestDispatcher("DeleteEmployee.html").forward(request,
		 * response); }
		 */

	}

}
