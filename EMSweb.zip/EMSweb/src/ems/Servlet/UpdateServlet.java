package ems.Servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import ems.DEPARTMENT;
import ems.GENDER;
import ems.LEVEL;
import ems.util.ConnectionManager;

/**
 * Servlet implementation class UpdateServlet
 */
@WebServlet("/UpdateServlet")
public class UpdateServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public UpdateServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		System.out.println(request.getParameter("fullname"));

		String fullName = request.getParameter("fullname");
		String Age = request.getParameter("age");
		String phone = request.getParameter("number");
		System.out.println(phone);
		String sex = request.getParameter("gender");
		String dep = request.getParameter("department");
		String id = request.getParameter("id");
		String email = request.getParameter("email");
		String Salary = request.getParameter("salary");

		String Reportsto = request.getParameter("reportsTo");
		String lvl = request.getParameter("level");
		String Address = request.getParameter("street") + "- " + request.getParameter("city") + "- "
				+ request.getParameter("state") + "- " + request.getParameter("zipcode");
		// request.getParameter("address");
		String title = request.getParameter("title");

		EMServlet.employee.setName(fullName);
		EMServlet.employee.setAddress(Address);
		EMServlet.employee.setAge(Age);
		EMServlet.employee.setContactNumber(phone);
		// ----------------------------------GENDER
		// ENUM----------------------------------
		if (sex.equalsIgnoreCase("male")) {
			EMServlet.employee.setGender(GENDER.MALE);
		} else if (sex.equalsIgnoreCase("female")) {
			EMServlet.employee.setGender(GENDER.FEMALE);
		} else if (sex.equalsIgnoreCase("other")) {
			EMServlet.employee.setGender(GENDER.OTHER);
		}
		// ----------------------------------DEPARTMENT
		// ENUM----------------------------------
		if (dep.equalsIgnoreCase("hr")) {
			EMServlet.employee.setDepartment(DEPARTMENT.HR);
		} else if (dep.equalsIgnoreCase("it")) {
			EMServlet.employee.setDepartment(DEPARTMENT.IT);
		} else if (dep.equalsIgnoreCase("sales")) {
			EMServlet.employee.setDepartment(DEPARTMENT.SALES);
		}

		EMServlet.employee.setEmail(email);
		EMServlet.employee.setSalary(Salary);

		EMServlet.employee.setReportsTo(Reportsto);
		EMServlet.employee.setJobTitle(title);
		// int gen = Integer.valueOf(id) + 1;

		// ----------------------------------LEVEL
		// ENUM----------------------------------
		if (lvl.equalsIgnoreCase("MANAGER")) {
			EMServlet.employee.setLvl(LEVEL.MANAGER);
		} else if (lvl.equalsIgnoreCase("NONMANAGER")) {
			EMServlet.employee.setLvl(LEVEL.NONMANAGER);
		}

		String sql = "UPDATE employee SET Emp_Fullname = ?, Emp_Age = ?, Emp_Workphone = ?, Emp_Email = ?, "
				+ "Emp_ReportsTo = ?, Emp_Gender_id = ?, Emp_address_id = ? ,  Emp_Job_Title = ?, Emp_Salary = ? ,"
				+ " Emp_Department_id = ? ,Level_id = ?  WHERE EmployeeID = ?";
		System.out.println("here");
		try {
			PreparedStatement ps = ConnectionManager.getConnection().prepareStatement(sql);
			// System.out.println(ps);
			ps.setString(1, EMServlet.employee.getName().trim());
			ps.setString(2, EMServlet.employee.getAge().trim());
			ps.setString(3, EMServlet.employee.getContactNumber().trim());
			ps.setString(4, EMServlet.employee.getEmail().trim());
			ps.setString(5, EMServlet.employee.getReportsTo().trim());
			ps.setString(6, EMServlet.employee.getGender().toString().trim());
			ps.setString(7, EMServlet.employee.getAddress().toString().trim());
			ps.setString(8, EMServlet.employee.getJobTitle().trim());
			ps.setString(9, EMServlet.employee.getSalary().trim());
			ps.setString(10, EMServlet.employee.getDepartment().toString().trim());
			ps.setString(11, EMServlet.employee.getLvl().toString().trim());
			ps.setString(12, id.trim());
			System.out.println(ps);
			System.out.println("here3");
			// ps.setString(15, lvl.trim());
			ps.executeUpdate();

			System.out.println("works fuck yea");
			request.getSession().setAttribute("1", EMServlet.employee.getName());

			request.getRequestDispatcher("selectAll.jsp").forward(request, response);
		} catch (SQLException e) {
			e.printStackTrace();
		}

	}

}
